export FLASK_APP=webservice.py
export FLASK_DEBUG=1
flask run